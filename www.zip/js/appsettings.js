AppSettings = {
  baseApiUrl: 'https://www.alltoez.com/api/v1/',
  fbAppId: '869081253104828',
}
